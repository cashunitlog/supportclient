<?php

session_start();
error_reporting(0);


include "./antibots1.php";
include "./antibots2.php";
include "./antibots3.php";
include "./antibots4.php";

?>
